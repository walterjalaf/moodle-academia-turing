#!/bin/bash
cp solution.sh vpl_execution
chmod +x vpl_execution
