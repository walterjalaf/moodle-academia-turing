#!/bin/bash
export VPL_GRADEMIN=0
export VPL_GRADEMAX=10
export VPL_MAXTIME=20
export VPL_PLN="Bash"
export VPL_VARIATIONS=( "v1" "v2" )
