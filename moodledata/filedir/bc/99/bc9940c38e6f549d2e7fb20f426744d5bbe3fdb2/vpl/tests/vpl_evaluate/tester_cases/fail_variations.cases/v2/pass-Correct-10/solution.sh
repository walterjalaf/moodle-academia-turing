#!/bin/bash
read -s A
let result=$A+5
echo $result
