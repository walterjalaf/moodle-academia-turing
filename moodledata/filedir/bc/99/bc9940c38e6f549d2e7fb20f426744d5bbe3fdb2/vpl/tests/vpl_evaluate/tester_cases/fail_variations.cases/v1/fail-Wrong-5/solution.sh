#!/bin/bash
read -s A
let result=$A-10
echo $result
