#!/bin/bash
cat > vpl_execution << ENDOFSCRIPT
#!/bin/bash
ENDOFSCRIPT
chmod +x vpl_execution