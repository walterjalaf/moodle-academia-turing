#!/bin/bash
read -s A
let result=$A-1
echo $result
