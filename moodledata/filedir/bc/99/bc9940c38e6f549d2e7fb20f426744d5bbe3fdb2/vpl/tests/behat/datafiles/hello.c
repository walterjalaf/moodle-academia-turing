#include <stdio.h>
int main(){
	printf("Hello from C language!\n");
	printf("%d\n",  7 * 43);
	return 0;
}
