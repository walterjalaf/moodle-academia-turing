print("Hello from Python language!")
print(7 * 43)
