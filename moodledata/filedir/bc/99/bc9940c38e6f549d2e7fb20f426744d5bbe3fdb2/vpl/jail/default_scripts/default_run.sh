#!/bin/bash
# This file is part of VPL for Moodle
# Default run script for VPL
# Copyright (C) 2012 Juan Carlos Rodríguez-del-Pino
# License http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
# Author Juan Carlos Rodríguez-del-Pino <jcrodriguez@dis.ulpgc.es>

echo "I apologize, but I do not find a default action to run the submitted file types."
